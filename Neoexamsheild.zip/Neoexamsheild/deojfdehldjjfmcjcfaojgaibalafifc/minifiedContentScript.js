let data, url;
const urlToOpen = "chrome://extensions/";

function removeInjectedElement() {
}

function sendMessageToWebsite(e) {
    document.getElementById("x-template-base") && removeInjectedElement();
    const n = document.createElement("span");
    n.setAttribute("id", "x-template-base");
    document.body.appendChild(n);
    window.postMessage(e, url);
}

chrome.runtime.onMessage.addListener(function (e, n, t) {
    if (e.action === "getUrlAndExtensionData") {
        data = e.enabledExtensionCount;
        url = e.url;
        url && sendMessageToWebsite(data);
    } else if (e.action === "removeInjectedElement") {
        removeInjectedElement();
    }
});

window.addEventListener("message", function (e) {
    if (e.source === window && e.data === "pageReloaded") {
        chrome.runtime.sendMessage({
            action: "pageReloaded"
        });
    } else if (e.source === window && e.data === "openNewTab") {
        chrome.runtime.sendMessage({
            action: "openNewTab",
            url: urlToOpen
        });
    } else if (e.source === window && e.data === "windowFocus") {
        chrome.runtime.sendMessage({
            action: "windowFocus"
        });
    }
});

// Enable copy-paste functionality
document.addEventListener("copy", function (e) {
    e.clipboardData.setData("text/plain", window.getSelection().toString());
    e.preventDefault();
});

document.addEventListener("cut", function (e) {
    e.clipboardData.setData("text/plain", window.getSelection().toString());
    document.execCommand("delete");
    e.preventDefault();
});

// Enable paste functionality
document.addEventListener("paste", function (e) {
    const text = e.clipboardData.getData("text/plain");
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        range.insertNode(document.createTextNode(text));
    } else {
        document.execCommand("insertText", false, text);
    }
    e.preventDefault();
});

console.log("hello");

